## a14-made-labs1
Repository ini berisi kode hasil dari codelab yang ada di **Modul 1 kelas Menjadi Android Developer Expert di Dicoding**.
Di dalamnya terdapat materi:
* Activity
* Intent
* Fragment
* ListView
* Unit Test

Jadilah expert di dunia pemrograman Android. Materi disusun oleh **Dicoding sebagai Google Authorized Training Partner**.
Ikuti [kelas Menjadi Android Developer Expert](https://www.dicoding.com/academies/14/) di Dicoding Indonesia
